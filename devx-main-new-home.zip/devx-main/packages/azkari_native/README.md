ضع ملف الأذان هنا باسم `adhan` (ogg أو mp3 أو wav):

    packages/azkari_native/android/src/main/res/raw/adhan.ogg

باقي الإعدادات (الخدمات، الأذونات، الأيقونة الشفافة) جاهزة وتُدمج تلقائيًا في البناء.
