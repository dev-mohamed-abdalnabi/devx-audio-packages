# Full Adhan Audio

- File: `adhan.ogg`
- Source: [Adhan Notifications on Internet Archive](https://archive.org/details/adhan.notifications)
- Recording: `Nasser_al_Qatami_Adhan.ogg`
- Listed license: **Public Domain Mark 1.0**
- Duration: approximately 2 minutes 12 seconds
- Source checked: 2026-10-03

The Internet Archive item lists this recording under the Public Domain Mark. It is bundled as the app's full adhan notification. The app does not claim endorsement by the named reciter.
